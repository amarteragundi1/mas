# Front-End Developers to Learn From

The notion that you should follow an individual to learn about front-end development is slowly becoming pointless. The advanced practitioners of front-end development generate enough content that you can simply follow the community/leaders by paying attention to the front-end "news" outlets (via [Newsletters, News, & Podcasts](../learning/news-podcasts.md)).
