# Learn Computer Science via JS 

* [Four Semesters of Computer Science in Six Hours](https://frontendmasters.com/courses/computer-science/) [video][$]
* [Four Semesters of Computer Science in Six Hours: Part 2](https://frontendmasters.com/courses/computer-science-2/) [video][$]
* [Computer Science in JavaScript](https://github.com/davidshariff/computer-science) [read]
* [Collection of classic computer science paradigms, algorithms, and approaches written in JavaScript](https://github.com/nzakas/computer-science-in-javascript) [read]
* [Algorithms and Data Structures in JavaScript](https://frontendmasters.com/workshops/algorithms-data-structures-js/) [watch][$]
