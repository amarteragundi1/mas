# Learn State Management

* [State management in JavaScript](https://codeburst.io/state-management-in-javascript-15d0d98837e1) [read]
* [Advanced State Management in React (feat. Redux and MobX)](https://frontendmasters.com/courses/react-state/) [watch][$]
* [React js tutorial - How Redux Works](https://www.youtube.com/watch?v=1w-oQ-i1XB8&list=PLoYCgNOIyGADILc3iUJzygCqC8Tt3bRXt) [watch]
* [MobX + React is AWESOME](https://www.youtube.com/watch?v=_q50BXqkAfI&t=10s) [watch]






























