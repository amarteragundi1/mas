# Learn Data (i.e. JSON) API Design

* [REST & GraphQL API Design in Node.js, v2 (using Express & MongoDB)](https://frontendmasters.com/courses/api-node-rest-graphql/) [watch][$]
* [Build APIs You Won't Hate](http://apisyouwonthate.com/) [$][read]
* [JSON API ](http://jsonapi.org/) [read]
* [RESTful Web API Design with Node.JS - Second Edition](https://www.amazon.com/RESTful-Web-API-Design-Node-JS/dp/1786469138?&_encoding=UTF8&tag=frontend-handbook-20&linkCode=ur2&linkId=65822660966bb9c5339b4b411ef25d73&camp=1789&creative=9325) [$][read]




















































