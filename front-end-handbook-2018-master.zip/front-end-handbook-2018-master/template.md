# First Chapter

GitBook allows you to organize your book into chapters, each chapter is stored in a separate file like this one.
