# Part I. The Front-End Practice

Part one broadly describes the practice of front-end engineering.



