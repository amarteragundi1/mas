# Front-End Data Storage Tools (i.e. Data storage solution in the client)

* [AlaSQL](http://alasql.org/)
* [Dexie.js](http://www.dexie.org/)
* [LocalForage](https://localforage.github.io/localForage/)
* [LokiJS](http://lokijs.org/#/)
* [Lovefield](https://google.github.io/lovefield)
* [lowdb](https://github.com/typicode/lowdb)
* [Pouchdb](http://pouchdb.com/)
* [NeDB](https://github.com/louischatriot/nedb)
* [RxDB](https://pubkey.github.io/rxdb/install.html)











































 






