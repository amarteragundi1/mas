# Font Tools 

##### Free Web Fonts:

* [fonts.com](http://www.fonts.com/) [free to $]
* [Google Fonts](http://fortawesome.github.io/Font-Awesome/)
* [TypeKit](https://typekit.com) [free to $]

##### Icon Fonts:

* [Devicons](http://vorillaz.github.io/devicons/#/main)
* [Font Awesome](http://fortawesome.github.io/Font-Awesome/)
* [Fontello](http://fontello.com/)
* [GitHub Octicons](https://octicons.github.com/)
* [ionicons](http://ionicons.com/)

##### JS Font Tools:

* [FlowType.js](http://simplefocus.com/flowtype/)
* [localFont](https://github.com/jaicab/localFont)
* [Web Font Loader](https://github.com/typekit/webfontloader)










































 






