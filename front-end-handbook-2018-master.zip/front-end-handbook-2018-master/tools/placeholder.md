# Placeholder Content Tools

## Images:
* [placehold.it](http://placehold.it)
* [Satyr](http://satyr.io)
* [Placeimg](http://placeimg.com)
* [Lorem Pixel](http://lorempixel.com)
* [CSS-Tricks Image Resources](https://css-tricks.com/sites-with-high-quality-photos-you-can-use-for-free/)
* [LibreStock](http://librestock.com)
* [Unsplash](https://unsplash.it)
* [Place Beyoncé](http://placebeyonce.com)

## Device Mockups:
* [placeit.net](https://placeit.net)
* [mockuphone.com](http://mockuphone.com)

## Text:
* [Meet the Ipsums](http://meettheipsums.com)
* [catipsum.com](http://www.catipsum.com/)
* [baconipsum.com](http://baconipsum.com/) ([API](http://baconipsum.com/json-api/))

## User Data:
* [uinames.com](https://uinames.com)
* [randomuser.me](https://randomuser.me)
