# Doc/API Browsing Tools

Tools to browse common developer documents and developer API references.

* [Dash](https://kapeli.com/dash) [OS X, iOS][$]
* [DevDocs](http://devdocs.io/)
* [Velocity](https://velocity.silverlakesoftware.com/) [Windows][$]
* [Zeal](https://zealdocs.org/) [Windows, Linux]

Cheatsheets:

* [devhints.io](https://devhints.io)










































 






