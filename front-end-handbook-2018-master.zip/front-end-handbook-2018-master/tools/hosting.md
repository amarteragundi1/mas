# Hosting Tools

##### General

* [AWS](https://aws.amazon.com/websites/) [$]
* [DigitalOcean](https://digitalocean.com) [$]
* [WebFaction](https://www.webfaction.com/) [$]

##### Static

* [Firebase Hosting](https://firebase.google.com/docs/hosting/) [free to $]
* [netlify](https://www.netlify.com) [free to $]
  * [Bitballoon](https://www.bitballoon.com/)
* [Surge](https://surge.sh/) [free to $]
* [Forge](https://getforge.com/) [$]

##### Local Hosting Tools:

* [Localname](https://localname.io)