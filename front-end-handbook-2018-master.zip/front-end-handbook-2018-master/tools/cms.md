# Content Management Hosted/API Tools 

##### Headless CMS Tools:

* [Contentful](https://www.contentful.com/) [$]
* [prismic.io](https://prismic.io/) [free to $]
* [Headless](https://www.headless.rest/)

##### Self-hosted Headless CMS Tools:

* [Cockpit](https://getcockpit.com/)

##### Hosted CMS:

* [LightCMS](https://www.lightcms.com) [$]
* [Surreal CMS](http://www.surrealcms.com/) [$]

##### Static CMS Tools:

* [webhook.com](http://www.webhook.com/)
* [Dato CMS](https://www.datocms.com/)
* [siteleaf](https://www.siteleaf.com/)
* [forestry.io](https://forestry.io/)








































 






