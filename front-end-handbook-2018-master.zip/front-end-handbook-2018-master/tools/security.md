# Security Tools

##### Coding Tool:

* [DOMPurify](https://github.com/cure53/DOMPurify)
* [XSS](http://jsxss.com/en/index.html)

##### Security Scanners/Evaluators/Testers:

* [Netsparker](https://www.netsparker.com)
* [Websecurify](http://www.websecurify.com/)
* [OWASP ZAP](https://www.owasp.org/index.php/OWASP_Zed_Attack_Proxy_Project)

##### References:

* [HTML5 Security Cheatsheet](https://html5sec.org/)




































 






