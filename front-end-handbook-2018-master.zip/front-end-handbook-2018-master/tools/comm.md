# Collaboration & Communication Tools

* [Slack](https://slack.com/) & [screenhero](https://screenhero.com/) [free to $]
* [appear.in](https://appear.in/)
* [Mattermost](https://mattermost.org/) [free to $]

##### Code/GitHub Collaboration & Communication:

* [Gitter](https://gitter.im) [free to $]


































 






