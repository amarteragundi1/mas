# Animation Tools

##### CSS and JavaScript Utilities:

* [Animate Plus](https://github.com/bendc/animateplus)
* [Animate](https://github.com/daneden/animate.css)
* [Anime.js](http://animejs.com/)
* [Animista.net](http://animista.net/)
* [Dynamics.js](http://dynamicsjs.com/)
* [GreenSock-JS](http://greensock.com/)
* [Kute.js](http://thednp.github.io/kute.js/)
* [Magic](https://github.com/miniMAC/magic)
* [Micron.js](https://webkul.github.io/micron/)
* [Motion](http://mojs.io/)
* [TweenJS](https://github.com/CreateJS/TweenJS)
* [Popmotion](https://popmotion.io)
* [Velocity.js](http://julian.com/research/velocity/)

##### Polyfills/Shims:

* [web-animations-js](https://github.com/web-animations/web-animations-js)

##### Animation References:

* [canianimate.com](http://canianimate.com/)








































 






